package windows;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
//import utils.Utils;

public class FrameDemo {

	@Test
	public void frameDemo() {
		
		System.setProperty("webdriver.chrome.driver", "C:\\automation\\drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();

		driver.get("https://www.w3schools.com/tags/tryit.asp?filename=tryhtml_input_test");
		driver.findElement(By.cssSelector(".topnav-icons.fa.fa-adjust")).click();
		
		//move to frame
		WebElement fr = driver.findElement(By.cssSelector("#iframeResult"));
		driver.switchTo().frame(fr);
		
		driver.findElement(By.cssSelector("[name='fname']")).clear();
		driver.findElement(By.cssSelector("[name='fname']")).sendKeys("gal");
		driver.findElement(By.cssSelector("[name='lname']")).clear();
		driver.findElement(By.cssSelector("[name='lname']")).sendKeys("matalon");
		driver.findElement(By.cssSelector("[value='Submit']")).click();
		
		//back to main window
		driver.switchTo().defaultContent();			
	}
	
	@Test
	public void windowsDemo() {
		System.setProperty("webdriver.chrome.driver", "C:\\automation\\drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://automation.co.il/tutorials/html/selenium-difference-between-close-and-quit.html");
		driver.findElement(By.cssSelector("#linkgoogle")).click();
		String mainWindow = driver.getWindowHandle();
		Set<String> windows = driver.getWindowHandles();
		for (String win : windows) {
			driver.switchTo().window(win);
		}
		//google
		driver.findElement(By.cssSelector("[name='q']")).sendKeys("tent");
		driver.findElement(By.cssSelector("[name='q']")).submit();
		driver.close();
		driver.switchTo().window(mainWindow);
		
	}

}
