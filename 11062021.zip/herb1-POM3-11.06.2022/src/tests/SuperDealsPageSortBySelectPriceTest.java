package tests;

//import org.openqa.selenium.NoSuchElementException;
import org.testng.Assert;
import org.testng.annotations.Test;

import pageobjects.MainPageBeforeSignIn;
import pageobjects.SelectLanguagePage;
import pageobjects.SuperDealsPage;
import pageobjects.SuperDealsSortedBySelectPricePage;

import org.openqa.selenium.NoSuchElementException;
public class SuperDealsPageSortBySelectPriceTest extends BaseTest{
	@Test(description = "sort by SelectPrice +check validation:")
	public void tc01_SortBySelectPriceTest() throws InterruptedException {		
		driver.get("https://il.iherb.com/");
		MainPageBeforeSignIn mp=new MainPageBeforeSignIn(driver);
		mp.openSelectLanguage();		
		SelectLanguagePage slp=new SelectLanguagePage(driver);
		slp.selectLanguageCurrencyCountry("English","USD","CA - Canada");
		mp=new MainPageBeforeSignIn(driver);
		mp.openSuperDealsPage();		
		SuperDealsPage sdp=new SuperDealsPage(driver);		
		sdp.closeAdvertisement();

		sdp.openSuperDealsProductsAfterSortBySelectPrice("Price: Low to High");
		
		SuperDealsSortedBySelectPricePage sdsp=new SuperDealsSortedBySelectPricePage(driver);
		boolean actual=sdsp.isCheckSortedPriceAfterSortByPriceLowToHigh1();
		try {
		Assert.assertTrue(actual);
		} catch (NoSuchElementException e) {
			// TODO Auto-generated catch block
			System.out.println("Error ");
		}	
		driver.close();
	}

}
